/**
 * Action Registry System - Phase 7
 * Centralized system for managing social actions
 * Data-driven approach for easy content addition
 */

import { DutyType } from '../schedule.js';
import fs from 'fs';
import path from 'path';

/**
 * Action Registry class for managing social actions
 */
export class ActionRegistry {
  constructor() {
    this.actions = new Map();
    this.categories = new Map();
  }
  
  /**
   * Register a new action
   * @param {Object} action - Action definition
   */
  register(action) {
    // Validate required properties
    const required = ['id', 'label', 'cooldown', 'requires', 'apply'];
    const missing = required.filter(prop => !action[prop]);
    
    if (missing.length > 0) {
      throw new Error(`Action missing required properties: ${missing.join(', ')}`);
    }
    
    // Check for duplicate IDs
    if (this.actions.has(action.id)) {
      throw new Error(`Action with id "${action.id}" already registered`);
    }
    
    // Register action
    this.actions.set(action.id, action);
    
    // Add to category if specified
    if (action.category) {
      if (!this.categories.has(action.category)) {
        this.categories.set(action.category, []);
      }
      this.categories.get(action.category).push(action);
    }
  }
  
  /**
   * Get action by ID
   * @param {string} id - Action ID
   * @returns {Object} Action definition
   */
  get(id) {
    return this.actions.get(id);
  }
  
  /**
   * Get available actions for context
   * @param {Object} context - Current context
   * @returns {Array} Available actions
   */
  getAvailable(context) {
    const available = [];
    
    for (const action of this.actions.values()) {
      // Check kingdom restriction
      if (action.kingdom) {
        // Allow if context kingdom matches OR NPC is in that kingdom
        const kingdomMatch = context.kingdom === action.kingdom || 
                           (context.npc && context.npc.kingdomId === action.kingdom);
        if (!kingdomMatch) {
          continue;
        }
      }
      
      // Check requirements
      if (action.requires(context)) {
        available.push(action);
      }
    }
    
    return available;
  }
  
  /**
   * Get actions by category
   * @param {string} category - Category name
   * @returns {Array} Actions in category
   */
  getByCategory(category) {
    return this.categories.get(category) || [];
  }
}

/**
 * Default social actions
 */
export const ACTIONS = {
  greet: {
    id: 'greet',
    label: 'Greet',
    cooldown: 1,
    category: 'social',
    requires: ({ attitude }) => attitude !== 'hostile',
    apply: ({ state, player, npc }) => {
      npc.social = npc.social || { trust: 0.5, fear: 0.2, respect: 0.3 };
      npc.social.trust += 0.05;
      if (state && state.log) {
        state.log(`${player.name} greets ${npc.name}`);
      }
      return { success: true, message: 'Greeting exchanged' };
    }
  },
  
  chat: {
    id: 'chat',
    label: 'Chat',
    cooldown: 2,
    category: 'social',
    requires: ({ attitude }) => attitude === 'friendly' || attitude === 'neutral',
    apply: ({ state, player, npc }) => {
      npc.social = npc.social || { trust: 0.5, fear: 0.2, respect: 0.3 };
      npc.social.trust += 0.08;
      return { success: true, message: 'Had a nice chat' };
    }
  },
  
  compliment: {
    id: 'compliment',
    label: 'Compliment',
    cooldown: 3,
    category: 'social',
    requires: ({ attitude }) => attitude === 'friendly' || attitude === 'neutral',
    apply: ({ state, player, npc }) => {
      npc.social = npc.social || { trust: 0.5, fear: 0.2, respect: 0.3 };
      npc.social.trust += 0.1;
      npc.social.respect += 0.05;
      return { success: true, message: 'Compliment appreciated' };
    }
  },
  
  insult: {
    id: 'insult',
    label: 'Insult',
    cooldown: 4,
    category: 'hostile',
    requires: () => true,
    apply: ({ state, player, npc }) => {
      npc.social = npc.social || { trust: 0.5, fear: 0.2, respect: 0.3 };
      npc.social.trust -= 0.15;
      npc.social.respect -= 0.1;
      return { success: true, message: 'Insult delivered' };
    }
  },
  
  threaten: {
    id: 'threaten',
    label: 'Threaten',
    cooldown: 5,
    category: 'hostile',
    requires: ({ attitude }) => attitude === 'hostile' || attitude === 'angry',
    apply: ({ state, player, npc }) => {
      npc.social = npc.social || { trust: 0.5, fear: 0.2, respect: 0.3 };
      npc.social.trust -= 0.2;
      npc.social.fear += 0.3;
      return { success: true, message: 'Threat issued' };
    }
  },
  
  gift: {
    id: 'gift',
    label: 'Give Gift',
    cooldown: 5,
    category: 'economic',
    requires: ({ attitude, player }) => {
      // Check hostile attitude
      if (attitude === 'hostile') return false;
      
      // If player exists and has inventory, check it's not empty
      if (player && player.inventory) {
        return player.inventory.length > 0;
      }
      
      // If no player or no inventory info, allow the action
      return true;
    },
    apply: ({ state, player, npc }) => {
      npc.social = npc.social || { trust: 0.5, fear: 0.2, respect: 0.3 };
      npc.social.trust += 0.2;
      npc.social.respect += 0.1;
      return { success: true, message: 'Gift received gratefully' };
    }
  },
  
  trade: {
    id: 'trade',
    label: 'Trade',
    cooldown: 3,
    category: 'economic',
    requires: ({ npc, hour }) => {
      // Check if NPC is a merchant
      if (!npc || npc.role !== 'merchant') return false;
      
      // If hour is provided, check schedule
      if (hour !== undefined && npc.schedule) {
        const currentDuty = npc.schedule.getCurrentDuty(hour);
        if (currentDuty === DutyType.SLEEP) return false;
        if (currentDuty === DutyType.TRADING) return true;
        // Allow other duties except sleep
        return currentDuty !== DutyType.SLEEP;
      }
      
      // Legacy check for currentDuty
      if (npc.currentDuty !== undefined) {
        if (npc.currentDuty === DutyType.SLEEP) return false;
        if (npc.currentDuty === DutyType.TRADING) return true;
      }
      
      return true; // Allow if no schedule
    },
    apply: ({ state, player, npc }) => {
      return { success: true, message: 'Trade completed' };
    }
  },
  
  share_rumor: {
    id: 'share_rumor',
    label: 'Share Rumor',
    cooldown: 2,
    category: 'social',
    requires: ({ attitude }) => attitude !== 'hostile',
    apply: ({ state, player, npc, params }) => {
      // Initialize or fix memory if needed
      if (!npc.memory) {
        npc.memory = { rumors: [] };
      }
      if (!npc.memory.rumors) {
        npc.memory.rumors = [];
      }
      if (!npc.memory.addRumor) {
        npc.memory.addRumor = function(r) { 
          if (r && !this.rumors.find(existing => existing.id === r.id)) {
            this.rumors.push(r);
          }
        };
      }
      
      // Initialize social if needed
      npc.social = npc.social || { trust: 0.5, fear: 0.2, respect: 0.3 };
      
      // Add rumor if provided
      if (params && params.rumor) {
        npc.memory.addRumor(params.rumor);
      }
      
      npc.social.trust += 0.05;
      return { success: true, message: 'Rumor shared' };
    }
  },
  
  hug: {
    id: 'hug',
    label: 'Hug',
    cooldown: 3,
    category: 'social',
    requires: ({ relationship, npc, player }) => {
      // Check relationship object first
      if (relationship && relationship.trust !== undefined) {
        return relationship.trust > 0.7;
      }
      
      // Check NPC's social values
      if (npc && npc.social && npc.social.trust !== undefined) {
        return npc.social.trust > 0.7;
      }
      
      // Check relation value from getRelationTo
      if (npc && player && npc.getRelationTo) {
        const relation = npc.getRelationTo(player);
        return relation > 0.5; // Positive relation threshold
      }
      
      return false;
    },
    apply: ({ state, player, npc }) => {
      npc.social = npc.social || { trust: 0.5, fear: 0.2, respect: 0.3 };
      npc.social.trust += 0.15;
      return { success: true, message: 'Warm hug exchanged' };
    }
  },
  
  arrest: {
    id: 'arrest',
    label: 'Arrest',
    cooldown: 10,
    category: 'authority',
    requires: ({ player }) => {
      // Only available if player is disguised as guard
      if (!player) return false;
      
      // Check for disguise object
      if (player.disguise && player.disguise.keys) {
        // Check if any disguise key is guard-related
        return player.disguise.keys.some(key => 
          key.includes('guard') || key === 'banana_guard'
        );
      }
      
      // Check for old-style single disguise
      if (player.disguiseKey) {
        return player.disguiseKey.includes('guard');
      }
      
      return false;
    },
    apply: ({ state, player, npc }) => {
      return { success: true, message: 'Arrest attempted' };
    }
  },
  
  pickpocket: {
    id: 'pickpocket',
    label: 'Pickpocket',
    cooldown: 5,
    category: 'criminal',
    requires: ({ kingdom, lawLevel }) => {
      // Only in lawless areas
      if (lawLevel !== undefined && lawLevel > 0.3) return false;
      return true;
    },
    apply: ({ state, player, npc }) => {
      return { success: true, message: 'Pickpocket attempted' };
    }
  }
};

/**
 * Kingdom-specific actions
 */
export const KINGDOM_ACTIONS = {
  candy: {
    praise_princess: {
      id: 'praise_pb',
      label: 'Praise Princess Bubblegum',
      kingdom: 'candy',
      cooldown: 2,
      category: 'social',
      requires: () => true,
      apply: ({ state, player, npc }) => {
        npc.social = npc.social || { trust: 0.5, fear: 0.2, respect: 0.3 };
        npc.social.respect += 0.1;
        return { success: true, message: 'Princess praised' };
      }
    },
    
    share_candy: {
      id: 'share_candy',
      label: 'Share Candy',
      kingdom: 'candy',
      cooldown: 3,
      category: 'social',
      requires: ({ attitude }) => attitude !== 'hostile',
      apply: ({ state, player, npc }) => {
        npc.social = npc.social || { trust: 0.5, fear: 0.2, respect: 0.3 };
        npc.social.trust += 0.1;
        return { success: true, message: 'Candy shared' };
      }
    }
  },
  
  fire: {
    flame_challenge: {
      id: 'flame_challenge',
      label: 'Challenge to Flame Battle',
      kingdom: 'fire',
      cooldown: 5,
      category: 'hostile',
      requires: () => true,
      apply: ({ state, player, npc }) => {
        npc.social = npc.social || { trust: 0.5, fear: 0.2, respect: 0.3 };
        npc.social.respect += 0.15;
        npc.social.fear += 0.1;
        return { success: true, message: 'Challenge issued' };
      }
    },
    
    show_respect: {
      id: 'show_respect',
      label: 'Show Respect',
      kingdom: 'fire',
      cooldown: 2,
      category: 'social',
      requires: () => true,
      apply: ({ state, player, npc }) => {
        npc.social = npc.social || { trust: 0.5, fear: 0.2, respect: 0.3 };
        npc.social.respect += 0.2;
        return { success: true, message: 'Respect shown' };
      }
    }
  },
  
  ice: {
    formal_greeting: {
      id: 'formal_greeting',
      label: 'Formal Greeting',
      kingdom: 'ice',
      cooldown: 2,
      category: 'social',
      requires: () => true,
      apply: ({ state, player, npc }) => {
        npc.social = npc.social || { trust: 0.5, fear: 0.2, respect: 0.3 };
        npc.social.respect += 0.08;
        npc.social.trust += 0.03;
        return { success: true, message: 'Formal greeting exchanged' };
      }
    },
    
    discuss_science: {
      id: 'discuss_science',
      label: 'Discuss Science',
      kingdom: 'ice',
      cooldown: 4,
      category: 'social',
      requires: ({ npc }) => npc.role === 'scientist' || npc.role === 'noble',
      apply: ({ state, player, npc }) => {
        npc.social = npc.social || { trust: 0.5, fear: 0.2, respect: 0.3 };
        npc.social.respect += 0.15;
        npc.social.trust += 0.05;
        return { success: true, message: 'Scientific discussion enjoyed' };
      }
    },
    
    exchange_intel: {
      id: 'exchange_intel',
      label: 'Exchange Intelligence',
      kingdom: 'ice',
      cooldown: 5,
      category: 'espionage',
      requires: ({ npc }) => {
        return npc.factions && npc.factions.includes('ice_spies');
      },
      apply: ({ state, player, npc }) => {
        return { success: true, message: 'Intelligence exchanged' };
      }
    }
  }
};

/**
 * Auto-discover actions from directory
 * @param {string} dir - Directory path
 * @returns {Array} Discovered actions
 */
export function discoverActions(dir) {
  const actions = [];
  
  try {
    const files = fs.readdirSync(dir);
    
    for (const file of files) {
      if (file.endsWith('.action.js')) {
        const actionPath = path.join(dir, file);
        const action = require(actionPath).default;
        
        if (action && action.id && action.label && action.apply) {
          actions.push(action);
        }
      }
    }
  } catch (error) {
    // Directory might not exist yet
    console.warn(`Could not discover actions from ${dir}:`, error.message);
  }
  
  return actions;
}

// Create default registry and register all actions
const defaultRegistry = new ActionRegistry();

// Register default actions
for (const action of Object.values(ACTIONS)) {
  defaultRegistry.register(action);
}

// Register kingdom actions
for (const kingdom of Object.values(KINGDOM_ACTIONS)) {
  for (const action of Object.values(kingdom)) {
    defaultRegistry.register(action);
  }
}

export default defaultRegistry;