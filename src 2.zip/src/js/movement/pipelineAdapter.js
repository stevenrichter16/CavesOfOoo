/**
 * Pipeline Adapter - Integrates the new MovementPipeline with existing code
 * This module provides a bridge between the old runPlayerMove function
 * and the new class-based MovementPipeline system
 */

import { movementPipeline } from './MovementPipeline.js';
import { gameEventBus } from '../systems/EventBus.js';

// Store original runPlayerMove for fallback
let originalRunPlayerMove = null;

/**
 * Feature flag to enable/disable new pipeline
 * Can be controlled via environment or settings
 */
export function isNewPipelineEnabled() {
  return process.env.USE_NEW_MOVEMENT !== 'false';
}

/**
 * Initialize the pipeline adapter
 * Sets up event listeners and prepares the system
 */
export function initializePipelineAdapter() {
  // Subscribe to movement events
  gameEventBus.on('WillMove', handleWillMove);
  gameEventBus.on('DidMove', handleDidMove);
  gameEventBus.on('MovementBlocked', handleMovementBlocked);
  gameEventBus.on('MovementComplete', handleMovementComplete);
  
  console.log(`Movement Pipeline Adapter initialized (new pipeline: ${isNewPipelineEnabled() ? 'enabled' : 'disabled'})`);
}

/**
 * Adapt the existing runPlayerMove to use the new pipeline
 * @param {Function} originalFunc - The original runPlayerMove function
 * @returns {Function} The adapted function
 */
export function adaptRunPlayerMove(originalFunc) {
  originalRunPlayerMove = originalFunc;
  
  return async function(state, action) {
    if (!isNewPipelineEnabled()) {
      // Use original implementation
      return originalFunc(state, action);
    }
    
    try {
      // Use new pipeline
      const result = await movementPipeline.execute(state, action);
      
      // Convert result to match expected return value
      // Original returns true if action was consumed
      return result.success || result.attacked || result.interacted || result.cancelled;
      
    } catch (error) {
      console.error('Error in new movement pipeline, falling back to original:', error);
      // Fallback to original implementation
      return originalFunc(state, action);
    }
  };
}

/**
 * Event Handlers
 */

function handleWillMove(data, result) {
  // Log pre-movement for debugging
  if (process.env.DEBUG_MOVEMENT) {
    console.log('WillMove:', data);
  }
}

function handleDidMove(data, result) {
  // Log successful movement
  if (process.env.DEBUG_MOVEMENT) {
    console.log('DidMove:', data);
  }
}

function handleMovementBlocked(data, result) {
  // Log blocked movement
  if (process.env.DEBUG_MOVEMENT) {
    console.log('Movement blocked:', data);
  }
}

function handleMovementComplete(data, result) {
  // Log movement completion with metrics
  if (process.env.DEBUG_MOVEMENT) {
    console.log('Movement complete:', data);
    if (data.result?.metrics) {
      console.log('Pipeline metrics:', data.result.metrics);
    }
  }
}

/**
 * Performance monitoring utilities
 */

export class MovementMetrics {
  constructor() {
    this.measurements = [];
    this.maxMeasurements = 100;
  }
  
  record(metrics) {
    this.measurements.push({
      timestamp: Date.now(),
      metrics
    });
    
    // Keep only recent measurements
    if (this.measurements.length > this.maxMeasurements) {
      this.measurements.shift();
    }
  }
  
  getAverages() {
    if (this.measurements.length === 0) return {};
    
    const sums = {};
    const counts = {};
    
    for (const measurement of this.measurements) {
      for (const [step, duration] of Object.entries(measurement.metrics)) {
        sums[step] = (sums[step] || 0) + duration;
        counts[step] = (counts[step] || 0) + 1;
      }
    }
    
    const averages = {};
    for (const step in sums) {
      averages[step] = sums[step] / counts[step];
    }
    
    return averages;
  }
  
  getReport() {
    const averages = this.getAverages();
    const total = Object.values(averages).reduce((sum, val) => sum + val, 0);
    
    return {
      stepAverages: averages,
      totalAverage: total,
      sampleSize: this.measurements.length
    };
  }
}

// Global metrics instance
export const movementMetrics = new MovementMetrics();

// Subscribe to movement completion to record metrics
gameEventBus.on('MovementComplete', (data) => {
  if (data.result?.metrics) {
    movementMetrics.record(data.result.metrics);
  }
});