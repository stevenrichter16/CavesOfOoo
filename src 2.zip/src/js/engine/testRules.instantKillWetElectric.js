// src/engine/testRules.instantKillWetElectric.js
// This rule has been moved to statusRules.js as 'wet_electric_lethal_test'
// Keeping this file empty for backward compatibility