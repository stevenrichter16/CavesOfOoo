// src/engine/universalRules.js
// Minimal placeholder; imports ensure materials/status defaults are registered.
import './materials.js';
// You can add general rules here later (ignite, douse, corrosion, etc.).